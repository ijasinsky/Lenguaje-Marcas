package com.example.act81;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

public class GameView extends View {
    private Bitmap starship;
    private Bitmap invader;
    private int screenWidth, screenHeight;
    private int invaderSize = 80;
    private int spaceshipWidth = 150;
    private int spaceshipHeight = 100;
    private int filas = 5;
    private int cols = 5;

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);

        // Cargar imágenes y redimensionarlas
        // Cargar imágenes y redimensionarlas
        starship = BitmapFactory.decodeResource(getResources(), R.drawable.starship);
        invader = BitmapFactory.decodeResource(getResources(), R.drawable.invader);

        starship = Bitmap.createScaledBitmap(starship, spaceshipWidth, spaceshipHeight, true);
        invader = Bitmap.createScaledBitmap(invader, invaderSize, invaderSize, true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        screenWidth = w;
        screenHeight = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Establecer el fondo negro
        canvas.drawColor(android.graphics.Color.BLACK);

        // Dibujar la nave en la parte inferior centrada
        int spaceshipX = (screenWidth - spaceshipWidth) / 2;
        int spaceshipY = screenHeight - spaceshipHeight - 20;
        canvas.drawBitmap(starship, spaceshipX, spaceshipY, null);

        // Dibujar los space invaders en 5 filas y 5 columnas en la parte superior izquierda
        for (int row = 0; row < filas; row++) {
            for (int col = 0; col < cols; col++) {
                int x = col * (invaderSize + 10); // Espaciado entre invaders
                int y = row * (invaderSize + 10);
                canvas.drawBitmap(invader, x, y, null);
            }
        }
    }
}
